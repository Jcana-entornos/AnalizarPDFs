import pdfplumber
import re
from collections import defaultdict
import sys

PDF_PATH = sys.argv[1]

# Diccionario para resultados
resultados = defaultdict(lambda: {"total": 0, "admitidos": 0})

# Expresión regular para detectar especialidad
regex_especialidad = re.compile(r"ESPECIALIDAD:\s*(.+)")

# Valores que consideramos "admitido"
VALORES_ADMITIDO = {"S", "SI"}

especialidad_actual = None

with pdfplumber.open(PDF_PATH) as pdf:
    for pagina in pdf.pages:
        texto = pagina.extract_text()

        if not texto:
            continue

        lineas = texto.split("\n")

        for linea in lineas:

            # 1️⃣ Detectar especialidad
            match = regex_especialidad.search(linea)
            if match:
                especialidad_actual = match.group(1).strip()
                continue

            # 2️⃣ Contar registros (líneas con DNI enmascarado)
            # Ejemplo: ****4439*
            if re.search(r"\*{4}\d{3,4}\*", linea):
                if especialidad_actual:
                    resultados[especialidad_actual]["total"] += 1

                # Buscar si en esa misma línea hay S o SI
                if any(val in linea.split() for val in VALORES_ADMITIDO):
                    resultados[especialidad_actual]["admitidos"] += 1

# 📊 Mostrar resultados
import json

print(json.dumps(resultados))