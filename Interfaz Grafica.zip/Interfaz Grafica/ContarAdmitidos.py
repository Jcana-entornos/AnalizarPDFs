import sys
import pdfplumber

ruta_pdf = sys.argv[1]
contador = 0

try:
    with pdfplumber.open(ruta_pdf) as pdf:
        for pagina in pdf.pages:
            texto = pagina.extract_text()
            if texto:
                for linea in texto.split("\n"):
                    if linea.strip().startswith("**") or linea.strip().startswith("R*"):
                        contador += 1

    print(contador)

except Exception as e:
    print("Error:", e) 